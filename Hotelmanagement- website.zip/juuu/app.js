
const products = [];
const categories = ['Electronics', 'Clothing', 'Books', 'Home & Garden', 'Sports'];
const brands = ['BrandA', 'BrandB', 'BrandC', 'BrandD', 'BrandE'];

function generateProducts() {
    for (let i = 1; i <= 40; i++) {
        const category = categories[Math.floor(Math.random() * categories.length)];
        const brand = brands[Math.floor(Math.random() * brands.length)];
        const basePrice = Math.floor(Math.random() * 1000) + 100; 
        const discountPercent = Math.floor(Math.random() * 50) + 5; 
        const price = Math.round(basePrice * (1 - discountPercent / 100));
        const mrp = basePrice;
        const rating = (Math.random() * 5).toFixed(1); 
        const reviewsCount = Math.floor(Math.random() * 1000) + 1;
        const stock = Math.floor(Math.random() * 50) + 1;

        products.push({
            id: i,
            title: `Product ${i} - ${category} Item ${brand}`,
            description: `Detailed description for Product ${i}. This is a high-quality ${category.toLowerCase()} item from ${brand}. Features include durability and style.`,
            price: price,
            mrp: mrp,
            discountPercent: discountPercent,
            rating: parseFloat(rating),
            reviewsCount: reviewsCount,
            brand: brand,
            category: category,
            imageUrl: `https://picsum.photos/seed/${i}/400/400`,
            stock: stock
        });
    }
}

generateProducts();


let allProducts = [...products];
let filteredProducts = [...products];
let displayedProducts = [];
let currentPage = 0;
const itemsPerPage = 12;
let cart = JSON.parse(localStorage.getItem('cart')) || [];


function debounce(func, delay) {
    let timeoutId;
    return function (...args) {
        clearTimeout(timeoutId);
        timeoutId = setTimeout(() => func.apply(this, args), delay);
    };
}


function updateCartBadge() {
    const badge = document.getElementById('cartBadge');
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    badge.textContent = totalItems;
    badge.style.display = totalItems > 0 ? 'inline' : 'none';
}


function saveCart() {
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartBadge();
}


function renderProducts(productsToRender = displayedProducts) {
    const grid = document.getElementById('productsGrid');
    const loadMoreBtn = document.getElementById('loadMore');
    const noProducts = document.getElementById('noProducts');

    if (productsToRender.length === 0) {
        grid.innerHTML = '';
        noProducts.style.display = 'block';
        loadMoreBtn.style.display = 'none';
        return;
    }

    noProducts.style.display = 'none';

    
    const start = currentPage * itemsPerPage;
    const end = start + itemsPerPage;
    const pageProducts = productsToRender.slice(start, end);

    if (start === 0) {
        grid.innerHTML = '';
        displayedProducts = [];
    }

    pageProducts.forEach(product => {
        const card = document.createElement('div');
        card.className = 'product-card';
        card.innerHTML = `
            <img src="${product.imageUrl}" alt="${product.title}" loading="lazy">
            <h3>${product.title}</h3>
            <div class="stars" style="color: #ffd700;">${'★'.repeat(Math.floor(product.rating))}${'☆'.repeat(5 - Math.floor(product.rating))}</div>
            <p>${product.reviewsCount} reviews</p>
            <div class="price">
                <span class="mrp">$${product.mrp}</span>
                <span>$${product.price}</span>
                <span class="discount">${product.discountPercent}% off</span>
            </div>
            <button class="add-to-cart" onclick="addToCart